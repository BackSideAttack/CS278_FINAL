import {
  Timestamp,
  addDoc,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
  type Unsubscribe,
} from 'firebase/firestore';
import { db } from './config';
import { getUserProfileByHandle, type UserProfile } from './userService';

export interface Group {
  id: string;
  name: string;
  ownerHandle: string;
  memberHandles: string[];
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface GroupWithMembers extends Omit<Group, 'memberHandles'> {
  memberHandles: string[];
  members: UserProfile[];
}

/**
 * Create a new group
 */
export async function createGroup(
  name: string,
  memberHandles: string[],
  ownerHandle: string
): Promise<string> {
  if (!name.trim()) {
    throw new Error('Group name is required');
  }

  if (memberHandles.length === 0) {
    throw new Error('At least one member is required');
  }

  //const capitalizedOwner = ownerHandle.charAt(0).toUpperCase() + ownerHandle.slice(1);//WRONG LOGIC bruh
  const lowercaseOwner = ownerHandle.toLowerCase();

  const groupsRef = collection(db, 'groups');
  const groupData = {
    name: name.trim(),
    ownerHandle: lowercaseOwner,
    memberHandles,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  const docRef = await addDoc(groupsRef, groupData);

  //this is for the backend, we addd group ID to flp_names under owner handle
  const userRef = doc(db, 'flp_names', lowercaseOwner);
  await updateDoc(userRef, {
    groups: arrayUnion(docRef.id),
  });

  return docRef.id;
}

/**
 *so we can get all groups owned by the current user (by handle)
 */
export async function getMyGroups(ownerHandle: string): Promise<Group[]> {
  const groupsRef = collection(db, 'groups');
  const q = query(
    groupsRef,
    where('ownerHandle', '==', ownerHandle),
    orderBy('updatedAt', 'desc')
  );

  const querySnapshot = await getDocs(q);
  const groups: Group[] = [];

  querySnapshot.forEach((doc) => {
    groups.push({
      id: doc.id,
      ...doc.data(),
    } as Group);
  });

  return groups;
}

/**
 *now get groups with member details populated
 */
export async function getMyGroupsWithMembers(ownerHandle: string): Promise<GroupWithMembers[]> {
  const groups = await getMyGroups(ownerHandle);
  const groupsWithMembers: GroupWithMembers[] = [];

  for (const group of groups) {
    const members: UserProfile[] = [];

    for (const memberHandle of group.memberHandles) {
      const memberProfile = await getUserProfileByHandle(memberHandle);
      if (memberProfile) {
        members.push(memberProfile);
      }
    }

    groupsWithMembers.push({
      ...group,
      members,
    });
  }

  return groupsWithMembers;
}


export async function updateGroupName(
  groupId: string,
  newName: string
): Promise<void> {
  if (!newName.trim()) {
    throw new Error('Group name is required');
  }

  const groupRef = doc(db, 'groups', groupId);
  await updateDoc(groupRef, {
    name: newName.trim(),
    updatedAt: serverTimestamp(),
  });
}

//update the group memmbers 
export async function updateGroupMembers(
  groupId: string,
  memberHandles: string[]
): Promise<void> {
  if (memberHandles.length === 0) {
    throw new Error('At least one member is required');
  }

  const groupRef = doc(db, 'groups', groupId);
  await updateDoc(groupRef, {
    memberHandles,
    updatedAt: serverTimestamp(),
  });
}

//get rid of it
export async function deleteGroup(groupId: string): Promise<void> {
  const groupRef = doc(db, 'groups', groupId);
  await deleteDoc(groupRef);
}


export function subscribeToMyGroups(
  ownerHandle: string,
  callback: (groups: Group[]) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  const groupsRef = collection(db, 'groups');
  const q = query(
    groupsRef,
    where('ownerHandle', '==', ownerHandle),
    orderBy('updatedAt', 'desc')
  );

  return onSnapshot(
    q,
    (querySnapshot) => {
      const groups: Group[] = [];
      querySnapshot.forEach((doc) => {
        groups.push({
          id: doc.id,
          ...doc.data(),
        } as Group);
      });
      callback(groups);
    },
    onError
  );
}
